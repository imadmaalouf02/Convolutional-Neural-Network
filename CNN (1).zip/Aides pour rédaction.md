# ENSAM Template 

Ce template a pour objectif de simplifier l'utilisation de LaTeX pour tout le monde. Il faut avouer qu'au sein des Arts, LaTeX n'est pas extremement utile même si, d'experience, les profs vous donneront des points supplementaires pour des rendus en LaTeX. Par contre si vous allez dans une école étrangère pour un semestre ou plus, tout le monde utilise LaTeX et nombreux professeurs veulent seulement un rendu LaTeX.

Si vous débutez avec LaTeX, vous n'avez pas besoin de toucher le document "CoursENSAM.cls". Celui-ci sert seulement pour le bon fonctionnement du template et la mise en page. Nous y importons toutes les librairies necessaires normalement. Si vous êtes plus avancés n'hésitez pas à y faire des modifications ce n'est clairement pas parfaitement optimisé.

Les différents dossiers ont été pensé pour un rendu de rapport de stage. dans chaque dossier vous trouverez un document texte contenant le script de la partie en question et un dossier pour y insérer les images de cette partie. Ceci a pour objectif de faciliter la navigation et et l'organisation. Si vous modifiez les noms de dossier et/ou voulez en rajouter/enlever n'oubliez pas de modifier les input dans le document "main.tex".

Dans la partie 3, vous avez differents exemples de cas utiles lors de rendu de TP ou rapport de stage (insertion d'images, de codes informatiques etc...)

Dans le dossier "bibs", vous trouverez ou inserer votre bibliographique. Plusieurs exemples pour la nomenclature sont inserer ( un article / un livre / une partie d'un livre etc...). Pour qu'ils apparaissent vous devez les citer (\cite{...}), exemple en 3.5, sinon la page références sera vide. 

# Apprendre LaTeX

Pour apprendre LaTeX et aussi pour vous faciliter la vie nous vous conseillons d'utiliser ChatGPT. Il est tres compétant dans ce language donc n'hésitez pas.

Pour faciliter l'écriture d'équation le site " https://editor.codecogs.com/ " permet de générer le code LaTeX directement. 

Si vous avez une tablette, l'application " Mathpix" peut aussi etre utile. Vous écrivez une equation a la main sur votre tablette et elle vous génère automatiquement le code LaTeX, recuperable sur le site web "https://mathpix.com/".

Le site d'overleaf "https://www.overleaf.com/learn/" contient lui aussi beaucoup d'information

Dernier conseil pour les fractions utilisez \dfrac{}{} plutot que \frac{}{}, petite différence de présentation qui affiche la fraction en plus grand (d pour display). Ce shortcut fonctionne aussi pour d'autres fonctions appelées comme les intégrales. 

# Fin

Ce template a été ecrit par Louis REGNIER et Daniel VILLOREJO. Vous pouvez l'utiliser librement et vous n'avez pas besoin de nous citer.

Bonne chance pour vos cursus et si un jour vous nous croisez, proposez nous d'aller boire une Triple Karmeliet nous ne refuserons jamais.

QLTSAL,
L&za 6-39 Bo220
2'. 88-173 Bo220